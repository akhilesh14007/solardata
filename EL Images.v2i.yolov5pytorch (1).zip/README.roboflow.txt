
EL Images - v2 2021-10-05 6:56pm
==============================

This dataset was exported via roboflow.ai on October 5, 2021 at 1:33 PM GMT

It includes 1166 images.
Letters are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit within)

The following augmentation was applied to create 3 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Random rotation of between -0 and +0 degrees
* Random exposure adjustment of between -10 and +10 percent

The following transformations were applied to the bounding boxes of each image:
* 50% probability of horizontal flip


