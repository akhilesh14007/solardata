# detection > 2024-03-09 5:27pm
https://universe.roboflow.com/defect-detection-62nyd/detection-bc3wj

Provided by a Roboflow user
License: CC BY 4.0

